# ui/app.py (명령어 추가 기능 및 엔터키 여부 체크박스 추가)

import tkinter as tk
from tkinter import messagebox
import threading
from core.command_manager import CommandManager
from core.automator import Automator
from utils.logger import logger

class DifmApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Do it for me (difm)")

        self.command_manager = CommandManager()
        self.automator = Automator()

        self.commands = self.command_manager.get_all()

        self.create_widgets()
        self.populate_listbox()

    def create_widgets(self):
        # 리스트박스 및 스크롤바
        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=5)

        self.listbox = tk.Listbox(frame, height=10, width=40)
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.listbox.bind("<<ListboxSelect>>", self.on_command_select)

        scrollbar = tk.Scrollbar(frame, command=self.listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.listbox.config(yscrollcommand=scrollbar.set)

        # 상세 정보 입력란
        form = tk.Frame(self.root)
        form.pack(padx=10, pady=10, fill=tk.X)

        tk.Label(form, text="명령어 이름").grid(row=0, column=0, sticky=tk.W)
        self.name_var = tk.StringVar()
        self.name_entry = tk.Entry(form, textvariable=self.name_var, width=30)
        self.name_entry.grid(row=0, column=1, pady=2)

        tk.Label(form, text="메시지").grid(row=1, column=0, sticky=tk.W)
        self.message_var = tk.StringVar()
        self.message_entry = tk.Entry(form, textvariable=self.message_var, width=30)
        self.message_entry.grid(row=1, column=1, pady=2)

        tk.Label(form, text="마우스 X좌표").grid(row=2, column=0, sticky=tk.W)
        self.click_x_var = tk.IntVar()
        self.click_x_entry = tk.Entry(form, textvariable=self.click_x_var, width=10)
        self.click_x_entry.grid(row=2, column=1, sticky=tk.W, pady=2)

        tk.Label(form, text="마우스 Y좌표").grid(row=3, column=0, sticky=tk.W)
        self.click_y_var = tk.IntVar()
        self.click_y_entry = tk.Entry(form, textvariable=self.click_y_var, width=10)
        self.click_y_entry.grid(row=3, column=1, sticky=tk.W, pady=2)

        tk.Label(form, text="클릭 횟수").grid(row=4, column=0, sticky=tk.W)
        self.click_count_var = tk.IntVar(value=1)
        self.click_count_entry = tk.Entry(form, textvariable=self.click_count_var, width=10)
        self.click_count_entry.grid(row=4, column=1, sticky=tk.W, pady=2)

        # 엔터키 여부 체크박스
        self.enter_key_var = tk.BooleanVar(value=True)
        self.enter_check = tk.Checkbutton(form, text="엔터키 입력", variable=self.enter_key_var)
        self.enter_check.grid(row=5, column=1, sticky=tk.W, pady=2)

        # 버튼 프레임
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(pady=10)

        self.add_btn = tk.Button(btn_frame, text="추가", command=self.add_command)
        self.add_btn.pack(side=tk.LEFT, padx=5)

        self.update_btn = tk.Button(btn_frame, text="수정", command=self.update_command)
        self.update_btn.pack(side=tk.LEFT, padx=5)

        self.delete_btn = tk.Button(btn_frame, text="삭제", command=self.delete_command)
        self.delete_btn.pack(side=tk.LEFT, padx=5)

    def populate_listbox(self):
        self.listbox.delete(0, tk.END)
        self.commands = self.command_manager.get_all()
        for cmd in self.commands:
            self.listbox.insert(tk.END, cmd.get("name", "Unnamed Command"))

    def on_command_select(self, event):
        selection = self.listbox.curselection()
        if not selection:
            return
        index = selection[0]
        cmd = self.commands[index]
        # 상세 정보 입력란에 데이터 채우기
        self.name_var.set(cmd.get("name", ""))
        self.message_var.set(cmd.get("message", ""))
        self.click_x_var.set(cmd.get("click_x", 0))
        self.click_y_var.set(cmd.get("click_y", 0))
        self.click_count_var.set(cmd.get("click_count", 1))
        self.enter_key_var.set(cmd.get("enter_key", True))

    def add_command(self):
        new_cmd = {
            "name": self.name_var.get().strip(),
            "message": self.message_var.get(),
            "click_x": self.click_x_var.get(),
            "click_y": self.click_y_var.get(),
            "click_count": self.click_count_var.get(),
            "enter_key": self.enter_key_var.get()
        }
        if not new_cmd["name"]:
            messagebox.showwarning("경고", "명령어 이름은 비워둘 수 없습니다.")
            return
        self.command_manager.add(new_cmd)
        messagebox.showinfo("알림", "명령어가 추가되었습니다.")
        self.populate_listbox()
        self.clear_inputs()

    def update_command(self):
        selection = self.listbox.curselection()
        if not selection:
            messagebox.showwarning("경고", "수정할 명령어를 선택하세요.")
            return
        index = selection[0]

        new_cmd = {
            "name": self.name_var.get().strip(),
            "message": self.message_var.get(),
            "click_x": self.click_x_var.get(),
            "click_y": self.click_y_var.get(),
            "click_count": self.click_count_var.get(),
            "enter_key": self.enter_key_var.get()
        }

        if not new_cmd["name"]:
            messagebox.showwarning("경고", "명령어 이름은 비워둘 수 없습니다.")
            return

        success = self.command_manager.update(index, new_cmd)
        if success:
            messagebox.showinfo("알림", "명령어가 수정되었습니다.")
            self.populate_listbox()
        else:
            messagebox.showerror("오류", "명령어 수정에 실패했습니다.")

    def delete_command(self):
        selection = self.listbox.curselection()
        if not selection:
            messagebox.showwarning("경고", "삭제할 명령어를 선택하세요.")
            return
        index = selection[0]

        confirm = messagebox.askyesno("확인", "정말로 선택한 명령어를 삭제하시겠습니까?")
        if confirm:
            success = self.command_manager.delete(index)
            if success:
                messagebox.showinfo("알림", "명령어가 삭제되었습니다.")
                self.populate_listbox()
                self.clear_inputs()
            else:
                messagebox.showerror("오류", "명령어 삭제에 실패했습니다.")

    def clear_inputs(self):
        self.name_var.set("")
        self.message_var.set("")
        self.click_x_var.set(0)
        self.click_y_var.set(0)
        self.click_count_var.set(1)
        self.enter_key_var.set(True)

def main():
    root = tk.Tk()
    app = DifmApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
