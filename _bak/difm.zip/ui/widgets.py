# ui/widgets.py
import tkinter as tk

def create_command_listbox(parent, commands, on_select_callback):
    label = tk.Label(parent, text="명령어 목록")
    label.pack(pady=5)

    listbox = tk.Listbox(parent, height=15, width=50)
    for cmd in commands:
        listbox.insert(tk.END, cmd.get("name", "Unnamed Command"))
    listbox.pack(padx=10, pady=5)

    listbox.bind("<<ListboxSelect>>", on_select_callback)
    return listbox
