# core/automator.py
import pyautogui
import time

class Automator:
    def __init__(self, click_delay=0.1, type_interval=0.05):
        self.click_delay = click_delay
        self.type_interval = type_interval

    def run_command(self, cmd):
        try:
            x, y = cmd.get("click_x", 0), cmd.get("click_y", 0)
            count = cmd.get("click_count", 1)
            message = cmd.get("message", "")
            enter_key = cmd.get("enter_key", False)

            # 마우스 이동 및 클릭
            pyautogui.moveTo(x, y)
            for _ in range(count):
                pyautogui.click()
                time.sleep(self.click_delay)

            # 메시지 입력
            if message:
                pyautogui.write(message, interval=self.type_interval)

            # 엔터키 입력
            if enter_key:
                pyautogui.press("enter")

            return True, f'명령어 "{cmd.get("name", "")}" 실행 완료.'
        except Exception as e:
            return False, str(e)
